import asyncio
import logging
from contextlib import asynccontextmanager
from typing import Optional

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from fastapi import FastAPI

from app.bot.handlers import router
from app.config.settings import settings, validate_settings

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)

# Останавливаем запуск сразу с понятной ошибкой, если .env не заполнен.
validate_settings()

bot = Bot(
    token=settings.TELEGRAM_BOT_TOKEN,
    default=DefaultBotProperties(parse_mode=ParseMode.HTML),
)
dp = Dispatcher()
dp.include_router(router)

_polling_task: Optional[asyncio.Task] = None


async def _run_polling() -> None:
    logger.info("Запуск long polling для Telegram-бота N1 Safar Taxi")
    try:
        await dp.start_polling(bot)
    except asyncio.CancelledError:
        logger.info("Polling отменён (нормальное завершение)")
        raise
    except Exception:
        # Например, неправильный TELEGRAM_BOT_TOKEN — aiogram выбросит
        # ошибку авторизации при первом запросе к Telegram API.
        logger.exception(
            "Polling остановлен из-за ошибки. Проверьте TELEGRAM_BOT_TOKEN."
        )


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _polling_task
    _polling_task = asyncio.create_task(_run_polling())
    logger.info("FastAPI приложение запущено, бот работает в фоне")

    yield

    logger.info("Остановка приложения...")
    await dp.stop_polling()
    if _polling_task is not None:
        _polling_task.cancel()
        try:
            await _polling_task
        except asyncio.CancelledError:
            pass
    await bot.session.close()
    logger.info("Бот остановлен")


app = FastAPI(title="N1 Safar Taxi Bot", lifespan=lifespan)


@app.get("/")
async def health_check() -> dict:
    """Простой эндпоинт для проверки, что процесс жив (например, для Render/Railway)."""
    return {"status": "ok", "service": "N1 Safar Taxi Bot"}
