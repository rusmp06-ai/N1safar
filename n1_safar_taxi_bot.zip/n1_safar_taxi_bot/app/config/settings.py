import os
import sys
import logging

from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)


class Settings:
    """
    Централизованная конфигурация проекта.
    Все значения читаются из переменных окружения (.env).
    """

    TELEGRAM_BOT_TOKEN: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    GROQ_API_KEY: str = os.getenv("GROQ_API_KEY", "")
    GROQ_MODEL: str = os.getenv("GROQ_MODEL", "openai/gpt-oss-120b")

    # Сколько последних сообщений (user+assistant) хранить на одного
    # Telegram-пользователя, чтобы история не росла бесконечно.
    MAX_HISTORY_MESSAGES: int = int(os.getenv("MAX_HISTORY_MESSAGES", "20"))

    # Максимальная длина входящего сообщения от пользователя (в символах).
    MAX_MESSAGE_LENGTH: int = int(os.getenv("MAX_MESSAGE_LENGTH", "2000"))


settings = Settings()


def validate_settings() -> None:
    """
    Проверяет, что все обязательные переменные окружения заданы.
    Если чего-то не хватает — останавливает запуск с понятной ошибкой,
    вместо того чтобы падать позже с непонятным исключением.
    """
    missing = []

    if not settings.TELEGRAM_BOT_TOKEN:
        missing.append("TELEGRAM_BOT_TOKEN")
    if not settings.GROQ_API_KEY:
        missing.append("GROQ_API_KEY")

    if missing:
        logger.error(
            "Отсутствуют обязательные переменные окружения: %s. "
            "Заполните файл .env на основе .env.example",
            ", ".join(missing),
        )
        sys.exit(1)
