from collections import defaultdict, deque
from typing import Deque, Dict, List

from app.config.settings import settings


class ChatHistoryStore:
    """
    Простое хранилище истории диалогов в памяти приложения.

    У каждого Telegram user_id — своя история сообщений вида
    {"role": "user"/"assistant", "content": str}.

    История автоматически обрезается: deque с maxlen хранит только
    последние MAX_HISTORY_MESSAGES сообщений на пользователя, старые
    сообщения выталкиваются сами по себе — история не растёт бесконечно.

    ВНИМАНИЕ: история хранится в оперативной памяти процесса и очищается
    при перезапуске бота. На следующем этапе (когда подключим SQLite/CRM)
    это хранилище можно будет заменить на persistent-версию с тем же
    интерфейсом (add_message / get_history / clear), не меняя остальной код.
    """

    def __init__(self, max_messages: int) -> None:
        self._max_messages = max_messages
        self._store: Dict[int, Deque[dict]] = defaultdict(
            lambda: deque(maxlen=self._max_messages)
        )

    def add_message(self, user_id: int, role: str, content: str) -> None:
        self._store[user_id].append({"role": role, "content": content})

    def get_history(self, user_id: int) -> List[dict]:
        return list(self._store[user_id])

    def clear(self, user_id: int) -> None:
        self._store[user_id].clear()


history_store = ChatHistoryStore(max_messages=settings.MAX_HISTORY_MESSAGES)
