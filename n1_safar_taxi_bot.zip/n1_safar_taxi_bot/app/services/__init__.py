"""
Пакет для сервисов интеграции с CRM/бронированием.

Зарезервировано для следующего этапа, когда AI получит tools/function calling:
check_route, get_price, get_schedule, check_available_seats,
create_booking, cancel_booking, notify_admin.

Пока пуст — на первом этапе бот только разговаривает с клиентом.
"""
