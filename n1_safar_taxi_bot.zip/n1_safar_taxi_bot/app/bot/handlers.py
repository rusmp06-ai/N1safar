import logging

from aiogram import F, Router
from aiogram.exceptions import TelegramAPIError
from aiogram.filters import CommandStart
from aiogram.types import Message

from app.ai.client import AIServiceError, ai_client
from app.config.settings import settings
from app.database.history import history_store

logger = logging.getLogger(__name__)

router = Router()

WELCOME_MESSAGE = (
    "Здравствуйте! 👋 Добро пожаловать в N1 Safar Taxi.\n"
    "Я помогу ответить на ваши вопросы о поездках. Чем могу помочь?"
)

FRIENDLY_ERROR_MESSAGE = (
    "Извините, сейчас возникла небольшая техническая проблема. "
    "Попробуйте написать ещё раз через минуту."
)

TOO_LONG_MESSAGE = (
    "Ваше сообщение слишком длинное 🙏 Пожалуйста, сократите его и "
    "отправьте ещё раз."
)

EMPTY_MESSAGE_REPLY = "Пожалуйста, напишите ваш вопрос текстом 🙂"

NON_TEXT_REPLY = (
    "Сейчас я умею отвечать только на текстовые сообщения 🙂 "
    "Пожалуйста, напишите вопрос текстом."
)


@router.message(CommandStart())
async def handle_start(message: Message) -> None:
    user_id = message.from_user.id if message.from_user else 0
    logger.info("user_id=%s начал новый диалог (/start)", user_id)
    history_store.clear(user_id)
    await message.answer(WELCOME_MESSAGE)


@router.message(F.text)
async def handle_text_message(message: Message) -> None:
    user_id = message.from_user.id if message.from_user else 0
    text = message.text or ""

    logger.info("Получено сообщение от user_id=%s, длина=%d", user_id, len(text))

    if not text.strip():
        await message.answer(EMPTY_MESSAGE_REPLY)
        return

    if len(text) > settings.MAX_MESSAGE_LENGTH:
        logger.warning(
            "user_id=%s прислал слишком длинное сообщение (%d символов)",
            user_id,
            len(text),
        )
        await message.answer(TOO_LONG_MESSAGE)
        return

    history_store.add_message(user_id, "user", text)

    try:
        logger.info("Отправка запроса в Groq AI для user_id=%s", user_id)
        reply = ai_client.generate_reply(history_store.get_history(user_id))
        logger.info("Успешно получен ответ от Groq AI для user_id=%s", user_id)
    except AIServiceError as exc:
        logger.error("Ошибка AI-сервиса (%s) для user_id=%s", exc, user_id)
        await message.answer(FRIENDLY_ERROR_MESSAGE)
        return

    history_store.add_message(user_id, "assistant", reply)

    try:
        await message.answer(reply)
    except TelegramAPIError:
        logger.exception(
            "Ошибка Telegram API при отправке ответа user_id=%s", user_id
        )


@router.message()
async def handle_non_text_message(message: Message) -> None:
    # Голосовые, фото, стикеры и т.д. — на первом этапе не обрабатываем.
    user_id = message.from_user.id if message.from_user else 0
    logger.info("user_id=%s прислал не текстовое сообщение", user_id)
    await message.answer(NON_TEXT_REPLY)
