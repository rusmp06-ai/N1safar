import logging
from typing import List

from groq import (
    APIConnectionError,
    APIStatusError,
    APITimeoutError,
    Groq,
    RateLimitError,
)

from app.ai.prompts import SYSTEM_PROMPT
from app.config.settings import settings

logger = logging.getLogger(__name__)


class AIServiceError(Exception):
    """
    Базовое исключение для всех ошибок AI-сервиса.
    Ловится на уровне обработчика бота, чтобы показать пользователю
    понятное сообщение и не уронить весь бот из-за одного неудачного запроса.
    """


class GroqAIClient:
    def __init__(self) -> None:
        self._client = Groq(api_key=settings.GROQ_API_KEY)
        self._model = settings.GROQ_MODEL

    def generate_reply(self, history: List[dict]) -> str:
        """
        Отправляет историю диалога в Groq и возвращает текст ответа.

        history — список сообщений вида {"role": "user"/"assistant", "content": str},
        БЕЗ системного промпта (он добавляется автоматически внутри метода).
        """
        messages = [{"role": "system", "content": SYSTEM_PROMPT}] + history

        try:
            completion = self._client.chat.completions.create(
                model=self._model,
                messages=messages,
                temperature=0.6,
                max_tokens=600,
            )
        except RateLimitError as exc:
            logger.error("Groq API: превышен лимит запросов: %s", exc)
            raise AIServiceError("rate_limit") from exc
        except APITimeoutError as exc:
            logger.error("Groq API: таймаут запроса: %s", exc)
            raise AIServiceError("timeout") from exc
        except APIConnectionError as exc:
            logger.error("Groq API: сетевая ошибка при обращении к API: %s", exc)
            raise AIServiceError("connection") from exc
        except APIStatusError as exc:
            logger.error(
                "Groq API вернул ошибку статуса %s: %s", exc.status_code, exc
            )
            if exc.status_code == 401:
                raise AIServiceError("invalid_api_key") from exc
            if exc.status_code == 404:
                # Обычно означает, что модель из GROQ_MODEL недоступна/устарела.
                raise AIServiceError("model_not_found") from exc
            raise AIServiceError("api_error") from exc
        except Exception as exc:  # noqa: BLE001 — последний рубеж защиты
            logger.exception("Неожиданная ошибка при обращении к Groq API")
            raise AIServiceError("unknown") from exc

        if not completion.choices:
            logger.error("Groq API вернул ответ без вариантов (choices пуст)")
            raise AIServiceError("empty_response")

        reply = completion.choices[0].message.content
        if not reply or not reply.strip():
            logger.error("Groq API вернул пустое сообщение")
            raise AIServiceError("empty_response")

        return reply.strip()


ai_client = GroqAIClient()
